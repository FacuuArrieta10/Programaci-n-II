
package Ejercicios;

public class Variables {

   
    public static void main(String[] args) {
       
       String nombre = "Facu";
       int edad = 22;
       double altura = 1.67;
       boolean estudiante = true; 
      
        System.out.println("Nombre: " + nombre);
        System.out.println("Edad: " + edad);
        System.out.println("Altura: " + altura);
        System.out.println("Estudiante: " + estudiante);
        
        
    }

}
