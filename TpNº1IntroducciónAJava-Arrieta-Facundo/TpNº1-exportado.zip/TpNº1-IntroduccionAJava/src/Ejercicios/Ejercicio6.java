
package Ejercicios;

public class Ejercicio6 {
    public static void main(String[] args) {
        System.out.println("Nombre: Juan Pérez\nEdad: 30 años\nDirección: \"Calle Falsa 123\"");
    }
}

